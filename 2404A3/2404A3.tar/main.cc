#include <iostream>
using namespace std;
#include <string>

#include "Control.h"


int main()
{
  Control control;

  control.launch();

  return 0;
}

