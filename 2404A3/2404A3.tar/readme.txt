Program Author: Christine Laurendeau
Revision Author: Raden Mathieu Almaden (101104851)

Purpose: To create a library that logs whether or not books are checked in or out.

Source Files:
Book.cc
Control.cc
Library.cc
List.cc
Logger.cc
main.cc
View.cc

Header Files:
Book.h
Control.h
Library.h
List.h
Logger.h
View.h

Compilation:
Run the makefile.
Startup
Run the "./a3" command to test the program after compilation.
